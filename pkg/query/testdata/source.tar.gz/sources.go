package debuginfo

import (
	"archive/tar"
	"compress/gzip"
	"errors"
	"fmt"
	"io"

	"github.com/klauspost/compress/zstd"
)

type SourcesReader struct {
	r           *tar.Reader
	maxFileSize int64
}

const (
	gzipID1     = 0x1f
	gzipID2     = 0x8b
	gzipDeflate = 8
)

func NewSourcesReader(r io.ReaderAt) (*SourcesReader, error) {
	magic := make([]byte, 4)
	_, err := r.ReadAt(magic, 0)
	if err != nil {
		return nil, fmt.Errorf("read magic: %v", err)
	}

	const maxint64 = 1<<63 - 1
	// 1MB buffer means we read the underlying reader in chunks of 1MB.
	sr := io.NewSectionReader(r, 0, maxint64)

	var compressedReader io.Reader
	if magic[0] == gzipID1 && magic[1] == gzipID2 && magic[2] == gzipDeflate {
		compressedReader, err = gzip.NewReader(sr)
		if err != nil {
			return nil, fmt.Errorf("new gzip reader: %v", err)
		}
	}

	if magic[0] == 0x37 && magic[1] == 0xa4 && magic[2] == 0x30 && magic[3] == 0xec {
		compressedReader, err = zstd.NewReader(sr)
		if err != nil {
			return nil, fmt.Errorf("new zstd reader: %v", err)
		}
	}

	if compressedReader == nil {
		return nil, errors.New("unknown compression format")
	}

	return &SourcesReader{
		r:           tar.NewReader(compressedReader),
		maxFileSize: 1024 * 1024 * 100, // 100MB
	}, nil
}

func (s *SourcesReader) Find(filename string) ([]byte, error) {
	path := trimLeadingSlash(filename)
	for {
		header, err := s.r.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, fmt.Errorf("next tar entry: %v", err)
		}

		if header.Typeflag == tar.TypeReg {
			if header.Size > s.maxFileSize {
				return nil, fmt.Errorf("file %s is too large (%d bytes)", header.Name, header.Size)
			}

			if header.Name == path {
				buf := make([]byte, header.Size)
				_, err := io.ReadFull(s.r, buf)
				if err != nil {
					return nil, fmt.Errorf("read file %s: %v", header.Name, err)
				}
				return buf, nil
			}

			// Skip the file.
			_, err := io.CopyN(io.Discard, s.r, header.Size)
			if err != nil {
				return nil, fmt.Errorf("skip file %s: %v", header.Name, err)
			}
		}
	}

	return nil, errors.New("source file not found")
}

func trimLeadingSlash(s string) string {
	if len(s) > 0 && s[0] == '/' {
		return s[1:]
	}
	return s
}
