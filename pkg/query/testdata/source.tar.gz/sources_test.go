package debuginfo

import (
	"io"
	"net/http"
	"os"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestFindSourcesFile(t *testing.T) {
	resp, err := http.Get("https://github.com/parca-dev/parca/archive/refs/tags/v0.18.0.tar.gz")
	require.NoError(t, err)
	defer resp.Body.Close()

	tmp, err := os.CreateTemp("", "sources_test")
	require.NoError(t, err)
	defer os.Remove(tmp.Name())
	defer tmp.Close()

	_, err = io.Copy(tmp, resp.Body)
	require.NoError(t, err)

	s, err := NewSourcesReader(tmp)
	require.NoError(t, err)

	_, err = s.Find("parca-0.18.0/cmd/parca/main.go")
	require.NoError(t, err)
}

func BenchmarkFindSourcesFile(b *testing.B) {
	b.Skip()

	resp, err := http.Get("https://github.com/parca-dev/parca/archive/refs/tags/v0.18.0.tar.gz")
	require.NoError(b, err)
	defer resp.Body.Close()

	tmp, err := os.CreateTemp("", "sources_test")
	require.NoError(b, err)
	defer os.Remove(tmp.Name())
	defer tmp.Close()

	_, err = io.Copy(tmp, resp.Body)
	require.NoError(b, err)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		s, err := NewSourcesReader(tmp)
		require.NoError(b, err)

		_, err = s.Find("parca-0.18.0/cmd/parca/main.go")
		require.NoError(b, err)
	}
}
